## ------------------------------------------------------------------------
library(tablr)
library(dplyr)

## ------------------------------------------------------------------------
str(shooting_spend)
str(shooting)

## ----, eval=FALSE--------------------------------------------------------
#  # An example: the tablr sample datasets were created in this way
#  shooting <- load_spss("data/main_clean.sav")
#  shooting_spend <- load_spss("data/spend_clean.sav")

## ------------------------------------------------------------------------
avg(shooting_spend, "spend", "item")
freq(shooting, "var7")

## ----, eval=FALSE--------------------------------------------------------
#  avg(shooting_spend, "spend", "item") %>% html

## ----, results='asis', echo=FALSE----------------------------------------
a1 <- avg(shooting_spend, "spend", "item") %>% html(to_knitr = TRUE)
print(a1)

## ----, eval=FALSE--------------------------------------------------------
#  freq(shooting, "var7") %>% html

## ----, results='asis', echo=FALSE----------------------------------------
f1 <- freq(shooting, "var7") %>% html(to_knitr = TRUE)
f1

## ----, eval=FALSE--------------------------------------------------------
#  freq(shooting, "var7") %>% html_freq

## ----, results='asis', echo=FALSE----------------------------------------
f1 <- freq(shooting, "var7") %>% html_freq(to_knitr = TRUE)
f1

## ----, eval=FALSE--------------------------------------------------------
#  freq(shooting, "var7") %>% html_freq2

## ----, results='asis', echo=FALSE----------------------------------------
f1 <- freq(shooting, "var7") %>% html_freq2(to_knitr = TRUE)
f1

## ----, fig.width=6.5-----------------------------------------------------
freq(shooting, "var7") %>% freq_bar

## ----, eval=FALSE--------------------------------------------------------
#  f3 <- freq(shooting, "var8")
#  html_freq(f3, out = "f3.html")
#  freq_bar(f3, out = "f3.emf")

## ----, eval=FALSE--------------------------------------------------------
#  shooting_spend %>%
#      head(5) %>%
#      html(title = "First 5 rows of Fossil Pointe Spending Data")

## ----, results='asis', echo=FALSE----------------------------------------
t <- shooting_spend %>%
    head(5) %>%
    html(title = "First 5 rows of Fossil Pointe Spending Data", 
              to_knitr = TRUE)
t

## ----, eval=FALSE--------------------------------------------------------
#  shooting %>%
#      select(Vrid, var16:var18) %>%
#      left_join(shooting_spend) %>%
#      filter(item == "dine") %>%
#      arrange(desc(spend)) %>%
#      head(10) %>%
#      html(title = "The 10 Respondents who Spent the most on Dining")

## ----, results='asis', echo=FALSE----------------------------------------
t <- select(shooting, Vrid, var16:var18) %>%
    left_join(shooting_spend) %>%
    filter(item == "dine") %>%
    arrange(desc(spend)) %>%
    head(10) %>%
    html(title = "The 10 Respondents who Spent the most on Dining",
              to_knitr = TRUE)
t

## ----, eval=FALSE--------------------------------------------------------
#  shooting_spend %>%
#      group_by(type, item) %>%
#      summarize(spend = mean(spend)) %>%
#      html

## ----, results='asis', echo=FALSE----------------------------------------
t <- shooting_spend %>%
    group_by(type, item) %>%
    summarize(spend = mean(spend)) %>%
    html(to_knitr = TRUE)
t 

## ----, eval=FALSE--------------------------------------------------------
#  freq(shooting, "var7", groups = "var17") %>% html_freq

## ----, results='asis', echo=FALSE----------------------------------------
t <- freq(shooting, "var7", "var17") %>% html_freq(to_knitr = TRUE)
t

