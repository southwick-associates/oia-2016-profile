Author:
Date: 

The analysis is run using R. The R scripts are sourced from markdown files (.Rmd) 
using the knitr package (see doc for analysis summaries/documentation).

Workflow:


Directories:
- code      Code for analysis
- data      Raw and cleaned data
- doc       Analysis summaries
- out       Analysis output
- ref       Reference documentation

