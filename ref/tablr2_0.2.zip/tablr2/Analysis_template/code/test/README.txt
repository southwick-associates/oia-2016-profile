This is a place to put scripts to explore data, etc., that are not included in
the final analysis, but might be worth keeping for future reference.
