Author:
Date: 

The analysis is run using R.

Workflow:


Directories:
- code      Code for analysis
- data      Raw and cleaned data
- doc       Analysis summaries
- out       Analysis output
- ref       Reference documentation

